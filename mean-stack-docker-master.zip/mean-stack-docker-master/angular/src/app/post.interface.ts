export interface Post {
  _id: string;
  title: string;
  url: string;
  votes: number;
}
